var pos_0_0 = document.getElementById('pos_0_0');
var pos_0_1 = document.getElementById('pos_0_1');
var pos_0_2 = document.getElementById('pos_0_2');

var pos_1_0 = document.getElementById('pos_1_0');
var pos_1_1 = document.getElementById('pos_1_1');
var pos_1_2 = document.getElementById('pos_1_2');

var pos_2_0 = document.getElementById('pos_2_0');
var pos_2_1 = document.getElementById('pos_2_1');
var pos_2_2 = document.getElementById('pos_2_2');

var rejouer = document.getElementById('rejouer');

var grille = new Array();
var grilleId = new Array();

grille[0] = 0;
grille[1] = 0;
grille[2] = 0;

grille[3] = 0;
grille[4] = 0;
grille[5] = 0;

grille[6] = 0;
grille[7] = 0;
grille[8] = 0;


grilleId[0] = "pos_0_0";
grilleId[1] = "pos_0_1";
grilleId[2] = "pos_0_2";

grilleId[3] = "pos_1_0";
grilleId[4] = "pos_1_1";
grilleId[5] = "pos_1_2";

grilleId[6] = "pos_2_0";
grilleId[7] = "pos_2_1";
grilleId[8] = "pos_2_2";


function index(id) {
    switch (id) {
        case "pos_0_0":
            return 0;
            break;
        case "pos_0_1":
            return 1;
            break;
        case "pos_0_2":
            return 2;
            break;
        case "pos_1_0":
            return 3;
            break;
        case "pos_1_1":
            return 4;
            break;
        case "pos_1_2":
            return 5;
            break;
        case "pos_2_0":
            return 6;
            break;
        case "pos_2_1":
            return 7;
            break;
        case "pos_2_2":
            return 8;
            break;
    }
}




function getRandomInt(max) {
    return Math.floor(Math.random() * Math.floor(max));
}

function Machine_play() {

    do {
        do {

            nbAl = getRandomInt(9);
            console.log(nbAl);

        } while (grille[nbAl] == 2);


        if (grille[nbAl] == 0) {

            grille[nbAl] = 2;
            console.log(grille[nbAl]);
            console.log(grille[nbAl] != 0);

            var id = grilleId[nbAl];

            console.log(id);

            var caseId = document.getElementById(id);

            console.log(caseId);

            caseId.innerHTML = "<img src='x.gif'></img>";

            console.log(caseId);

        }

    } while (grille[nbAl] != 2);


}

var finJeu = 0;

function Test_gagne() {

    if (
        grille[0] == 1 && grille[1] == 1 && grille[2] == 1 ||
        grille[0] == 1 && grille[3] == 1 && grille[6] == 1 ||
        grille[0] == 1 && grille[4] == 1 && grille[8] == 1 ||
        grille[1] == 1 && grille[4] == 1 && grille[7] == 1 ||
        grille[2] == 1 && grille[5] == 1 && grille[8] == 1
    ) {
        console.log("Gagne");
        finJeu = 1;
    } else if (
        grille[0] == 2 && grille[1] == 2 && grille[2] == 2 ||
        grille[0] == 2 && grille[3] == 2 && grille[6] == 2 ||
        grille[0] == 2 && grille[4] == 2 && grille[8] == 2 ||
        grille[1] == 2 && grille[4] == 2 && grille[7] == 2 ||
        grille[2] == 2 && grille[5] == 2 && grille[8] == 2
    ) {
        console.log("Perdu");
        finJeu = 1;
    }

}

rejouer.onclick = function () {

    for (var i = 0; i < grille.length; i++) {
        grille[i] = 0;
        finJeu = 0;
        var id1;
        id1 = grilleId[i];
        var pos = document.getElementById(id1);
        pos.innerHTML = " ";

    }

}


function Jouer() {

    for (var i = 0; i < grilleId.length; i++) {

        var id;
        id = grilleId[i];
        var pos = document.getElementById(id);

        pos.onclick = function () {
            if (finJeu == 0) {
                this.innerHTML = "<img src='o.gif'></img>";
                grille[index(this.id)] = 1;
                Machine_play();
                Test_gagne();

            }
        }

    }

}

Jouer();
